# Strawberry Dataset (Good and Damaged) 
<br>
Author: Oka Mahendra
<br>
Resolution: 640 x 480
<br>
<br>
Capture with Logitech C170 web camera
<br>
382 good-strawberry photos
<br>
350 damaged-strawberry photos


